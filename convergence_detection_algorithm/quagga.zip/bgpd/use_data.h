#ifndef USE_DATA_H_
#define USE_DATA_H_

int modify_data(DATA *data_ptr);
int display_data(DATA *data_ptr);

#endif /*USE_DATA_H_*/