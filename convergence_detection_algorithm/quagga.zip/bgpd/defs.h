#ifndef DEFS_H_
#define DEFS_H_

typedef struct 
{
    int item1;
    int item2;
    float item3;
    float item4;
} DATA;

#endif /*DEFS_H_*/