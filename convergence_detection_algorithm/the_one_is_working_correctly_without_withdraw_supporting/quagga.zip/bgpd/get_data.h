#ifndef GET_DATA_H_
#define GET_DATA_H_

int get_data(DATA *data_ptr);

#endif /*GET_DATA_H_*/